import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from math import exp, atan, degrees
import os

def compute_rmse(y_true, y_pred):
    return np.linalg.norm(y_true - y_pred) / np.sqrt(len(y_true))

def compute_w2_index(y_true, y_pred, gamma=0.1):
    """Compute W2-index"""
    epsilon = 1e-8
    numerator = np.sum((y_true - y_pred) ** 2)
    denominator = np.sum(y_true ** 2) + epsilon
    q2 = 1 - numerator / denominator

    beta = np.sum(y_pred ** 2) / denominator
    beta = max(min(beta, 1e6), 1e-6)  # Limit value range

    F = abs(degrees(atan(abs((beta - 1) / (beta + 1)))))
    W2 = q2 * exp(-gamma * (F / 90.0))

    return W2, q2, F

# Generate data
np.random.seed(42)
x = np.linspace(0, 10, 100)
y_true = 2 * x + np.random.normal(0, 0.5, 100)

y_pred_A = 2.5 * x + np.random.normal(0, 0.3, 100)  
y_pred_B = 2 * x + np.random.normal(0, 1.0, 100)    
y_pred_C = 2.2 * x + np.random.normal(0, 0.7, 100) - 1  

data_df = pd.DataFrame({'x': x, 'y_true': y_true, 'y_pred_A': y_pred_A, 'y_pred_B': y_pred_B, 'y_pred_C': y_pred_C})

# Compute metrics
gamma = 1.0
models = {'Model A': y_pred_A, 'Model B': y_pred_B, 'Model C': y_pred_C}
results = []

for model_name, y_pred in models.items():
    rmse = compute_rmse(y_true, y_pred)
    w2, q2, f = compute_w2_index(y_true, y_pred, gamma=gamma)
    results.append({'Model': model_name, 'RMSE': rmse, 'W2': w2, 'q²': q2, 'F degree': f})
    
    data_df[f'{model_name}_RMSE'] = [rmse] * len(x)
    data_df[f'{model_name}_W2'] = [w2] * len(x)
    data_df[f'{model_name}_q2'] = [q2] * len(x)
    data_df[f'{model_name}_F'] = [f] * len(x)

# Save data
save_path = os.path.join(os.getcwd(), 'results\Fig1B\Fig1C-w2_demo_data.xlsx')
data_df.to_excel(save_path, index=False)
print(f"\nSample data saved to '{save_path}'")

# Results table
results_df = pd.DataFrame(results)
print("\nModel evaluation results:")
print(results_df.to_string(index=False))

# Plot figures
plt.figure(figsize=(18, 6))
for i, (model_name, y_pred) in enumerate(models.items(), 1):
    plt.subplot(1, 3, i)
    plt.scatter(y_true, y_pred, alpha=0.3, label='Data points')
    
    min_val = min(min(y_true), min(y_pred))
    max_val = max(max(y_true), max(y_pred))
    plt.plot([min_val, max_val], [min_val, max_val], 'r--', label='1:1 line')

    z = np.polyfit(y_true, y_pred, 1)
    p = np.poly1d(z)
    plt.plot(y_true, p(y_true), 'g-', label=f'Fitted line (slope={z[0]:.2f})')

    plt.xlabel('True Values')
    plt.ylabel('Predicted Values')
    plt.title(f'{model_name}\nRMSE={results[i-1]["RMSE"]:.3f}, W2={results[i-1]["W2"]:.3f}\nq²={results[i-1]["q²"]:.3f}, F={results[i-1]["F degree"]:.2f}°')
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()

plt.subplots_adjust(wspace=0.3)
fig_path = os.path.join(os.getcwd(), 'results\Fig1B\Fig1C-w2_index_comparison.png')
plt.savefig(fig_path, dpi=300, bbox_inches='tight')
plt.close()

print(f"\nFigure saved as '{fig_path}'")
