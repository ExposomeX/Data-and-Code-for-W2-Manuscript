import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.ticker import AutoMinorLocator
import matplotlib

matplotlib.use('Agg')  # Use non-interactive backend for headless execution

# Set the random seed for reproducibility
np.random.seed(42)

# 1) Parameter and Data Preparation
num_points = 1000000  # Number of data points per simulation
Q2_targets = np.linspace(-10, 1, 100)  # Target Q² values, evenly spaced between -10 and 1
gamma_values = [0.01, 0.1, 1, 10]  # Different gamma values for comparison
colors = ['b', 'g', 'r', 'purple']  # Different colors for each gamma value
markers = ['o', 'o', 'o', 'o']  # Same marker for all gamma values

# Generate a fixed set of observed values (y_obs) from a normal distribution
y_obs = np.random.normal(loc=0.0, scale=1.0, size=num_points)
y_obs_mean = y_obs.mean()

# Compute the total sum of squares for y_obs: SS = Σ((y_obs - y_obs_mean)²)
SS = np.sum((y_obs - y_obs_mean) ** 2)

# Iterate over different gamma values and generate separate plots
for gamma, color, marker in zip(gamma_values, colors, markers):
    Q2_list = []  # Actual Q² values computed from simulation
    J_list = []  # Indicator J for the current gamma

    for Q2_target in Q2_targets:
        # Calculate target PRESS using the relation Q² = 1 - (PRESS/SS)
        PRESS_target = (1 - Q2_target) * SS

        # Generate standard normal noise and scale it so that the sum of squared differences
        # between y_pred and y_obs equals PRESS_target.
        c_raw = np.random.normal(0, 1, size=num_points)
        c_norm_sq = np.sum(c_raw ** 2)

        # If the target Q² is 1 (i.e., PRESS_target is nearly 0), set y_pred equal to y_obs.
        if np.isclose(PRESS_target, 0, atol=1e-12):
            y_pred = y_obs.copy()
        else:
            scale_factor = np.sqrt(PRESS_target / c_norm_sq)
            y_pred = y_obs + scale_factor * c_raw

        # Compute actual Q²
        PRESS_actual = np.sum((y_pred - y_obs) ** 2)
        Q2_actual = 1 - PRESS_actual / SS

        # Compute regression coefficient β
        y_pred_mean = y_pred.mean()
        numerator = np.sum((y_obs - y_obs_mean) * (y_pred - y_pred_mean))
        denominator = np.sum((y_obs - y_obs_mean) ** 2)
        beta = numerator / denominator if not np.isclose(denominator, 0, atol=1e-12) else np.nan

        # Compute angle F (in degrees)
        if np.isfinite(beta):
            frac = np.inf if np.isclose(beta, -1, atol=1e-12) else abs((beta - 1) / (beta + 1))
            F_angle = np.degrees(np.arctan(frac))
        else:
            F_angle = np.nan

        # Compute final indicator J
        J_value = Q2_actual * np.exp(-gamma * F_angle) if np.isfinite(F_angle) else np.nan

        # Append computed metrics to their respective lists
        Q2_list.append(Q2_actual)
        J_list.append(J_value)

    # Create a new figure for the current gamma
    plt.figure(figsize=(7, 6), dpi=100)

    # Scatter plot for the current gamma
    plt.scatter(Q2_list, J_list, c=color, marker=marker, s=10)

    # Set axis labels
    plt.xlabel("Q²")
    plt.ylabel("J")

    # Set both x-axis and y-axis to symlog scale (supports both positive and negative values)
    plt.xscale("symlog", linthresh=1.0)
    plt.yscale("symlog", linthresh=1.0)

    # Format tick labels to scientific notation
    ax = plt.gca()
    ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%.1e'))
    ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%.1e'))

    # Enable minor ticks for a finer grid
    ax.xaxis.set_minor_locator(AutoMinorLocator(10))  # Divide each major tick interval into 5 minor ticks
    ax.yaxis.set_minor_locator(AutoMinorLocator(10))

    
    # Add major grid lines (solid, medium gray)
    ax.grid(which='major', linestyle='-', linewidth=0.5, color='0.6')
    # Add minor grid lines (dotted, light gray)
    ax.grid(which='minor', linestyle=':', linewidth=0.5, color='0.4')

    # Set x-axis range strictly between -10 and 1
    ax.set_xlim(-10, 1)

    plt.xlim(-10, 1)
    plt.ylim(-10, 1)

    # Fix missing '1' tick label on both x-axis and y-axis
    xticks = list(ax.get_xticks()) + [1]
    yticks = list(ax.get_yticks()) + [1]
    ax.set_xticks(sorted(set(xticks)))  # Ensure unique tick values
    ax.set_yticks(sorted(set(yticks)))

    # Dynamically adjust the y-axis based on actual J values
    if J_list and not all(np.isnan(J_list)):  # Ensure valid values before setting limits
        ax.set_ylim(min(J_list), max(J_list))

    # Remove extra margins so data points align with edges
    ax.margins(0)

    # Adjust layout to minimize extra space
    plt.tight_layout()

    # Add legend
    plt.legend()

    # Save the figure with the gamma value in the filename
    filename = f"results\Fig1B\Fig1B2-5-Q2_vs_J_gamma_{gamma}.png"
    plt.savefig(filename, dpi=300, bbox_inches='tight')

    # Close the figure to free up memory
    plt.close()

    print(f"Saved: {filename}")
