import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import pandas as pd
from math import atan, degrees
import os

from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import ElasticNet, Lasso
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from xgboost import XGBRegressor
from tabpfn import TabPFNRegressor

# ─── Metric functions ────────────────────────────────────────────────────────

def compute_rmse(y_true, y_pred):
    return np.linalg.norm(y_true - y_pred) / np.sqrt(len(y_true))

def compute_w2_index(y_true, y_pred, gamma=1.0):
    """Compute Q2, F, W2.
    Q2  = 1 - PRESS/SS = 1 - sum((y_pred - y_obs)^2) / sum((y_obs - mean(y_obs))^2)
    beta = OLS slope of y_pred on y_obs
         = sum((y_obs-mean_obs)(y_pred-mean_pred)) / sum((y_obs-mean_obs)^2)
    F   = angle between fit line (slope=beta) and 1:1 line (slope=1)
        = |arctan((beta-1)/(1+beta))| * 180/pi
    W2  = Q2 * exp(-gamma * F/90)
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    epsilon = 1e-8
    y_obs_c = y_true - y_true.mean()
    y_pred_c = y_pred - y_pred.mean()
    SS = np.sum(y_obs_c ** 2) + epsilon
    PRESS = np.sum((y_pred - y_true) ** 2)
    Q2 = 1 - PRESS / SS
    beta = np.sum(y_obs_c * y_pred_c) / SS
    beta = max(min(beta, 1e6), 1e-6)
    F = abs(degrees(atan(abs((beta - 1) / (beta + 1)))))
    W2 = Q2 * np.exp(-gamma * (F / 90.0))
    return Q2, F, W2

def make_model(name):
    if name == 'RF':
        return RandomForestRegressor(n_estimators=500, random_state=42, n_jobs=-1)
    elif name == 'XGBoost':
        return XGBRegressor(n_estimators=500, random_state=42,
                            eval_metric='rmse', verbosity=0)
    elif name == 'TabPFN':
        return TabPFNRegressor(
            model_path=r'C:\tabpfn_ckpt\tabpfn-v3-regressor-v3_20260417_mediumdata.ckpt',
            device='cpu',
        )
    elif name == 'SVR':
        return SVR(kernel='rbf', C=10, epsilon=0.1)
    elif name == 'ElasticNet':
        return ElasticNet(alpha=0.01, l1_ratio=0.5, max_iter=5000, random_state=42)
    elif name == 'Lasso':
        return Lasso(alpha=0.01, max_iter=5000, random_state=42)

# ─── Load data ───────────────────────────────────────────────────────────────

script_dir = os.path.dirname(os.path.abspath(__file__))
data_path = os.path.join(script_dir, 'data_raw', 'df_ehp_table_s2.xlsx')
df = pd.read_excel(data_path).reset_index(drop=True)

feature_cols = df.loc[:, 't1/2(day)':'Water solubility (µmol/L)'].columns.tolist()
target_col = 'ln_Observed concentration (µM)'

X_all = df[feature_cols].values
y_all = df[target_col].values
casrn_all = df['CASRN'].values

# ─── Setup ───────────────────────────────────────────────────────────────────

gamma = 1.0
N_SPLITS = 5
kf = KFold(n_splits=N_SPLITS, shuffle=True, random_state=13)
model_names = ['RF', 'XGBoost', 'TabPFN', 'SVR', 'ElasticNet', 'Lasso']

out_dir = os.path.join(script_dir, 'results', 'Fig1D')
os.makedirs(out_dir, exist_ok=True)

all_results = []
all_preds   = []

# ─── Loop over all 5 folds ────────────────────────────────────────────────────

for fold_idx, (train_idx, test_idx) in enumerate(kf.split(X_all), start=1):
    print(f"\n{'='*50}")
    print(f"Fold {fold_idx}/{N_SPLITS}")

    X_tr_raw, X_te_raw = X_all[train_idx], X_all[test_idx]
    y_tr, y_te = y_all[train_idx], y_all[test_idx]
    casrn_te   = casrn_all[test_idx]

    scaler = StandardScaler()
    X_tr = scaler.fit_transform(X_tr_raw)
    X_te = scaler.transform(X_te_raw)

    results     = []
    predictions = {}

    for name in model_names:
        print(f"  Training {name} ...")
        model = make_model(name)
        model.fit(X_tr, y_tr)
        y_pred_tr = model.predict(X_tr)
        y_pred_te = model.predict(X_te)

        Q2_tr, F_tr, W2_tr = compute_w2_index(y_tr, y_pred_tr, gamma)
        rmse_tr = compute_rmse(y_tr, y_pred_tr)
        Q2_te, F_te, W2_te = compute_w2_index(y_te, y_pred_te, gamma)
        rmse_te = compute_rmse(y_te, y_pred_te)
        slope_te = np.polyfit(y_te, y_pred_te, 1)[0]

        results.append({'Fold': fold_idx, 'Model': name, 'Set': 'Training',
                         'Q2': Q2_tr, 'F': F_tr, 'W2': W2_tr, 'RMSE': rmse_tr})
        results.append({'Fold': fold_idx, 'Model': name, 'Set': 'Testing',
                         'Q2': Q2_te, 'F': F_te, 'W2': W2_te, 'RMSE': rmse_te,
                         'slope': slope_te})
        predictions[name] = {'y_pred_te': y_pred_te, 'y_pred_tr': y_pred_tr}

        for j, (casrn, yo, yp) in enumerate(zip(casrn_te, y_te, y_pred_te)):
            all_preds.append({'Fold': fold_idx, 'Model': name, 'CASRN': casrn,
                               target_col: yo, 'y_pred': yp})

    results_df = pd.DataFrame(results)
    test_df    = results_df[results_df['Set'] == 'Testing'].set_index('Model')
    all_results.append(results_df)

    print(f"  Test set results (n={len(y_te)}):")
    print(test_df[['Q2', 'F', 'W2', 'RMSE']].to_string())

    # ── Figure 1: 2×3 scatter plots ──────────────────────────────────────────
    n_models = len(model_names)
    ncols, nrows = 3, 2
    fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 5 * nrows))
    fig.suptitle(
        f'Fold {fold_idx} – All Models: Observed vs Predicted (Test Set, n={len(y_te)})',
        fontsize=13, fontweight='bold', y=1.01
    )
    for i, name in enumerate(model_names):
        ax  = axes[i // ncols, i % ncols]
        yp  = predictions[name]['y_pred_te']
        row = test_df.loc[name]
        ax.scatter(y_te, yp, alpha=0.6, s=35, color='steelblue', zorder=3)
        axis_range = [-18, 1]
        ax.plot(axis_range, axis_range, 'r--', lw=1.5, zorder=2)
        z = np.polyfit(y_te, yp, 1)
        ax.plot(np.linspace(-18, 1, 200), np.poly1d(z)(np.linspace(-18, 1, 200)),
                'g-', lw=1.5, zorder=2)
        ax.set_xlim(-18, 1); ax.set_ylim(-18, 1)
        ax.set_xticks(np.arange(-18, 2, 4)); ax.set_yticks(np.arange(-18, 2, 4))
        ax.set_xlabel('Observed ln_Conc (µM)', fontsize=9)
        ax.set_ylabel('Predicted ln_Conc (µM)', fontsize=9)
        ax.set_title(f'{name}\nQ²={row["Q2"]:.3f}  W2={row["W2"]:.3f}\n'
                     f'F={row["F"]:.2f}°  RMSE={row["RMSE"]:.3f}', fontsize=9)
        ax.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    fig1_path = os.path.join(out_dir, f'Fig1D_fold{fold_idx}_obs_vs_pred.png')
    plt.savefig(fig1_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  Scatter plot saved to '{fig1_path}'")

    # ── Figure 2: W2 rationality (bubble + bar) ───────────────────────────────
    test_sub    = results_df[results_df['Set'] == 'Testing'].copy().reset_index(drop=True)
    colors      = plt.cm.tab10(np.linspace(0, 1, n_models))
    model_color = {n: colors[i] for i, n in enumerate(model_names)}

    fig2, axes2 = plt.subplots(1, 2, figsize=(21, 11.7))
    fig2.suptitle(
        f'W2-Index Rationality: Q² vs W2 for Different Models (Fold {fold_idx} Test Set)',
        fontsize=12, fontweight='bold'
    )

    # Panel A
    ax_a   = axes2[0]
    test_a = test_sub.sort_values('F', ascending=False).reset_index(drop=True)
    jitter_step = 0.001
    offsets = np.arange(len(test_a)) * jitter_step - (len(test_a)-1)*jitter_step/2
    for k, row2 in test_a.iterrows():
        ax_a.scatter(row2['Q2'] + offsets[k], row2['W2'],
                     s=max(row2['F'] * 120, 60),
                     color=model_color[row2['Model']], alpha=0.85,
                     edgecolors='k', linewidths=0.8,
                     label=f"{row2['Model']} Q²={row2['Q2']:.3f} W2={row2['W2']:.3f} F={row2['F']:.2f}°",
                     zorder=3)
    ax_a.set_xlabel('Q²', fontsize=11); ax_a.set_ylabel('W2', fontsize=11)
    ax_a.set_title('Panel A: Q² vs W2\n(bubble size ∝ F angle)', fontsize=10)
    ax_a.set_xlim(0.20, 0.50); ax_a.set_ylim(0.15, 0.45)
    ax_a.set_xticks(np.arange(0.20, 0.501, 0.05))
    ax_a.set_yticks(np.arange(0.15, 0.451, 0.05))
    ax_a.legend(fontsize=7, loc='upper left', framealpha=0.8, markerscale=0.5, handlelength=1.0)
    ax_a.grid(True, linestyle='--', alpha=0.4)

    # Panel B
    test_sorted = test_sub.sort_values('W2', ascending=False).reset_index(drop=True)
    ax_b   = axes2[1]
    ax_b_r = ax_b.twinx()
    x      = np.arange(n_models)
    bar_w  = 0.28
    bars_q2 = ax_b.bar(x - bar_w, test_sorted['Q2'], bar_w, label='Q²',    color='#4C72B0', alpha=0.85)
    bars_w2 = ax_b.bar(x,          test_sorted['W2'], bar_w, label='W2',    color='#DD8452', alpha=0.85)
    bars_f  = ax_b_r.bar(x + bar_w, test_sorted['F'],  bar_w, label='F (°)', color='#55A868', alpha=0.75)
    ax_b.set_xticks(x); ax_b.set_xticklabels(test_sorted['Model'], fontsize=9)
    ax_b.set_ylabel('Q² / W2', fontsize=11)
    ax_b.set_ylim(0.15, 0.50)
    ax_b.set_yticks(np.arange(0.15, 0.501, 0.05))
    ax_b.set_yticklabels([f'{v:.2f}' for v in np.arange(0.15, 0.501, 0.05)])
    ax_b_r.set_ylabel('F (°)', fontsize=11, color='#2d6a3f')
    ax_b_r.tick_params(axis='y', labelcolor='#2d6a3f')
    ax_b_r.set_ylim(0, 30); ax_b_r.set_yticks(np.arange(0, 31, 5))
    ax_b.set_title('Panel B: Q², W2 & F per Model\n(sorted by W2)', fontsize=10)
    ax_b.grid(True, axis='y', linestyle='--', alpha=0.4)
    ax_b.legend([bars_q2, bars_w2, bars_f], ['Q²', 'W2', 'F (°)'],
                fontsize=8, loc='upper right', bbox_to_anchor=(0.98, 0.98))
    plt.tight_layout()
    fig2_path = os.path.join(out_dir, f'Fig1D_fold{fold_idx}_W2_rationality.png')
    plt.savefig(fig2_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  W2 rationality plot saved to '{fig2_path}'")

    # ── Figure 3: standalone bar chart ───────────────────────────────────────
    fig3, ax3 = plt.subplots(figsize=(12, 4.8))
    ax3_r = ax3.twinx()
    bars3_q2 = ax3.bar(x - bar_w, test_sorted['Q2'], bar_w, label='Q²',    color='#4C72B0', alpha=0.85)
    bars3_w2 = ax3.bar(x,          test_sorted['W2'], bar_w, label='W2',    color='#DD8452', alpha=0.85)
    bars3_f  = ax3_r.bar(x + bar_w, test_sorted['F'],  bar_w, label='F (°)', color='#55A868', alpha=0.75)
    ax3.set_xticks(x); ax3.set_xticklabels(test_sorted['Model'], fontsize=10)
    ax3.set_ylabel('Q² / W2', fontsize=11)
    ax3.set_ylim(0.1, 0.70)
    ax3.set_yticks(np.arange(0.1, 0.701, 0.1))
    ax3.set_yticklabels([f'{v:.1f}' for v in np.arange(0.1, 0.701, 0.1)])
    ax3_r.set_ylabel('F (°)', fontsize=11, color='#2d6a3f')
    ax3_r.tick_params(axis='y', labelcolor='#2d6a3f')
    ax3_r.set_ylim(0, 30); ax3_r.set_yticks(np.arange(0, 31, 5))
    ax3.set_title(f'Q², W2 & F per Model (Fold {fold_idx} Test Set, sorted by W2)',
                  fontsize=10, fontweight='bold')
    ax3.grid(True, axis='y', linestyle='--', alpha=0.4)
    ax3.legend([bars3_q2, bars3_w2, bars3_f], ['Q²', 'W2', 'F (°)'],
               fontsize=9, loc='upper right')
    plt.tight_layout()
    fig3_path = os.path.join(out_dir, f'Fig1D_fold{fold_idx}_barplot.png')
    plt.savefig(fig3_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  Bar plot saved to '{fig3_path}'")

# ─── Save aggregated results ──────────────────────────────────────────────────

all_results_df = pd.concat(all_results, ignore_index=True)
all_results_df.to_excel(os.path.join(out_dir, 'all_folds_metrics.xlsx'), index=False)
pd.DataFrame(all_preds).to_excel(os.path.join(out_dir, 'all_folds_predictions.xlsx'), index=False)
print(f"\nAll results saved to '{out_dir}'")

# ─── Summary table: mean ± std across folds ───────────────────────────────────

test_all = all_results_df[all_results_df['Set'] == 'Testing']
summary = test_all.groupby('Model')[['Q2', 'F', 'W2', 'RMSE']].agg(['mean', 'std'])
print("\nSummary (mean ± std across 5 folds):")
print(summary.to_string())
summary.to_excel(os.path.join(out_dir, 'summary_5fold.xlsx'))
