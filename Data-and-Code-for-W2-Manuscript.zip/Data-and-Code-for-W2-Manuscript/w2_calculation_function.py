import numpy as np
from math import atan, degrees


def calculate_w2_index(y_true, y_pred, gamma=1.0):
    """
    Calculate the W2-index and its components for model evaluation.
    
    The W2-index is a comprehensive metric that combines prediction accuracy (Q²) 
    and slope deviation (F) to evaluate model performance.
    
    Parameters
    ----------
    y_true : array-like
        True observed values
    y_pred : array-like
        Predicted values from the model
    gamma : float, optional
        Penalty parameter for slope deviation (default: 1.0)
        Higher values increase the penalty for slope deviation
    
    Returns
    -------
    dict
        Dictionary containing:
        - 'Q2': Coefficient of determination (prediction accuracy)
        - 'F': Slope deviation angle in degrees
        - 'W2': W2-index value
    
    Notes
    -----
    The W2-index is calculated as:
        Q² = 1 - PRESS/SS = 1 - Σ(y_pred - y_obs)² / Σ(y_obs - ȳ_obs)²
        β = OLS slope of regression line (y_pred on y_obs)
            = Σ(y_obs - ȳ_obs)(y_pred - ȳ_pred) / Σ(y_obs - ȳ_obs)²
        F = |arctan((β - 1) / (1 + β))| × (180/π)   [angle between fit line and 1:1 line]
        W2 = Q² × exp(-γ × F/90)
    
    where:
    - Q² measures prediction accuracy (closer to 1 is better)
    - F measures slope deviation from the ideal 1:1 line (closer to 0 is better)
    - γ controls the penalty strength for slope deviation
    
    References
    ----------
    [Add your paper reference here]
    
    Examples
    --------
    >>> y_true = np.array([1, 2, 3, 4, 5])
    >>> y_pred = np.array([1.1, 2.0, 2.9, 4.1, 5.0])
    >>> results = calculate_w2_index(y_true, y_pred, gamma=1.0)
    >>> print(f"Q²: {results['Q2']:.4f}")
    >>> print(f"F: {results['F']:.2f}°")
    >>> print(f"W2-index: {results['W2']:.4f}")
    """
    # Convert to numpy arrays
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    
    # Add small epsilon to avoid division by zero
    epsilon = 1e-8
    
    # Calculate Q²: Q² = 1 - PRESS/SS (Eq.1)
    y_obs_c = y_true - y_true.mean()
    y_pred_c = y_pred - y_pred.mean()
    SS = np.sum(y_obs_c ** 2) + epsilon
    PRESS = np.sum((y_pred - y_true) ** 2)
    Q2 = 1 - PRESS / SS
    
    # Calculate beta: OLS slope of y_pred on y_obs
    # This gives the slope of the regression (fit) line in the obs-vs-pred plot
    beta = np.sum(y_obs_c * y_pred_c) / SS
    beta = max(min(beta, 1e6), 1e-6)  # Limit to reasonable range
    
    # Calculate F: angle between fit line (slope=beta) and 1:1 line (slope=1)
    # tan(angle between lines with slopes k1,k2) = |(k1-k2)/(1+k1*k2)|
    # Here k1=beta, k2=1 => |(beta-1)/(1+beta)|
    F = abs(degrees(atan(abs((beta - 1) / (beta + 1)))))
    
    # Calculate W2-index
    W2 = Q2 * np.exp(-gamma * (F / 90.0))
    
    return {
        'Q2': Q2,
        'F': F,
        'W2': W2
    }


if __name__ == "__main__":
    # Example usage demonstrating W2-index advantage
    np.random.seed(42)
    
    # Generate sample data
    y_true = np.array([2.5, 5.0, 7.5, 10.0, 12.5, 15.0, 17.5, 20.0])
    
    # Model A: Good prediction with slight slope deviation (F ≈ 10°)
    y_pred_A = 1.2 * y_true + np.random.normal(0, 0.3, len(y_true))
    
    # Model B: Good accuracy but larger slope deviation
    y_pred_B = 0.85 * y_true + np.random.normal(0, 0.3, len(y_true))
    
    # Calculate W2-index with gamma = 1
    results_A = calculate_w2_index(y_true, y_pred_A, gamma=1.0)
    results_B = calculate_w2_index(y_true, y_pred_B, gamma=1.0)
    
    print("W2-Index Advantage Demonstration:")
    print("=" * 50)
    print("\nModel A (slope ≈ 1.2):")
    print(f"  Q² (prediction accuracy): {results_A['Q2']:.4f}")
    print(f"  F (slope deviation): {results_A['F']:.2f}°")
    print(f"  W2-index: {results_A['W2']:.4f}")
    
    print("\nModel B (slope ≈ 0.85):")
    print(f"  Q² (prediction accuracy): {results_B['Q2']:.4f}")
    print(f"  F (slope deviation): {results_B['F']:.2f}°")
    print(f"  W2-index: {results_B['W2']:.4f}")
    
    print("\n" + "=" * 50)
    print("W2-index captures both accuracy AND slope deviation,")
    print("providing a more comprehensive model evaluation.")
