import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend to avoid display issues
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker as mticker
from matplotlib.ticker import AutoMinorLocator

# Define different gamma values
gamma_values = [0.01, 0.1, 1, 10]

# Generate F values (0 to 90 degrees)
F = np.linspace(0, 90, 200)

# Create figure
plt.figure(figsize=(10, 3), dpi=300)

# Plot J vs. F for different gamma values
for gamma in gamma_values:
    J = np.exp(-gamma * (F / 90))  # Compute J
    J = np.clip(J, 1e-10, 1)  # Avoid extremely small values for stability
    plt.plot(F, J, label=f'γ = {gamma}')

# Set axis labels
plt.xlabel("F (degrees)", fontsize=12)
plt.ylabel("J", fontsize=12)

# Set x-axis range from 0 to 90 with intervals of 10
plt.xticks(np.arange(0, 91, 10))  
plt.xlim(0, 90)
plt.ylim(0, 1)

# Format tick labels to scientific notation for better readability
ax = plt.gca()
ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('%.2f'))
ax.xaxis.set_major_formatter(mticker.FormatStrFormatter('%d'))

# Enable minor ticks for finer grid
ax.xaxis.set_minor_locator(AutoMinorLocator(5))
ax.yaxis.set_minor_locator(AutoMinorLocator(5))

# Add grid (both major and minor)
ax.grid(which='major', linestyle='-', linewidth=0.6, color='0.7')  # Major grid
ax.grid(which='minor', linestyle=':', linewidth=0.4, color='0.8')  # Minor grid

# Adjust legend placement to avoid overlap
# plt.legend(loc="upper right", fontsize=10, frameon=True)

 
# Save figure
plt.savefig("results\Fig1B\Fig1B1-J_vs_F.png", dpi=300, bbox_inches='tight')

# Close the plot to free memory
plt.close()

print("Plot saved as 'Fig1B1-J_vs_F.png' in the current directory.")
